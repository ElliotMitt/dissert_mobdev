package com.example.elliotmitt.calc_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void PlusClick(View cl) {
        EditText El1 = (EditText) findViewById(R.id.N1);
        EditText El2 = (EditText) findViewById(R.id.N2);
        TextView resText = (TextView) findViewById(R.id.Result);

        int num1 = Integer.parseInt(El1.getText().toString());
        int num2 = Integer.parseInt(El2.getText().toString());
        int rlsum = num1 + num2;
        resText.setText(Integer.toString(rlsum));

    }
    public void MinusClick(View cl) {
        EditText El1 = (EditText) findViewById(R.id.N1);
        EditText El2 = (EditText) findViewById(R.id.N2);
        TextView resText = (TextView) findViewById(R.id.Result);

        int num1 = Integer.parseInt(El1.getText().toString());
        int num2 = Integer.parseInt(El2.getText().toString());
        int rlmin = num1 - num2;
        resText.setText(Integer.toString(rlmin));
    }
    public void DelClick(View cl) {
        EditText El1 = (EditText) findViewById(R.id.N1);
        EditText El2 = (EditText) findViewById(R.id.N2);
        TextView resText = (TextView) findViewById(R.id.Result);

        int num1 = Integer.parseInt(El1.getText().toString());
        int num2 = Integer.parseInt(El2.getText().toString());
        int rldel = num1 / num2;
        resText.setText(Integer.toString(rldel));

    }
    public void MultiClick(View cl) {
        EditText El1 = (EditText) findViewById(R.id.N1);
        EditText El2 = (EditText) findViewById(R.id.N2);
        TextView resText = (TextView) findViewById(R.id.Result);

        int num1 = Integer.parseInt(El1.getText().toString());
        int num2 = Integer.parseInt(El2.getText().toString());
        int rlmlt = num1 * num2;
        resText.setText(Integer.toString(rlmlt));
    }

}