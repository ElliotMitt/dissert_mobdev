package com.testexam.elliotmitt.converter_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Конвертируем в доллары
    private float convertDollarToRouble(float dollar) {
        return (float) (dollar / 80.2);
    }

    // Конвертируем в рубли
    private float convertRoubleToDollar(float rouble) {
        return (float) (rouble * 80.2);
    }
    // Конвертируем в евро
    private float convertRoubleToEuro(float euro) {
        return (float) (euro * 90.3);
    }
    public void onClick(View view) {

        RadioButton tempRadioButton = findViewById(R.id.radio_button_dollar);
        EditText inputEditText = findViewById(R.id.editText);

        if (inputEditText.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Введите температуру",
                    Toast.LENGTH_LONG).show();
            return;
        }

        float inputValue = Float.parseFloat(inputEditText.getText().toString());
        if (tempRadioButton.isChecked()) {
            inputEditText.setText(String
                    .valueOf(convertDollarToRouble(inputValue)));
        } else if (tempRadioButton.isChecked()) {
            inputEditText.setText(String
                    .valueOf(convertRoubleToDollar(inputValue)));
        } else if (tempRadioButton.isChecked()) {
                inputEditText.setText(String
                        .valueOf(convertRoubleToEuro(inputValue)));
            }
        }

    }
